import streamlit as st
import requests

# News API Key (Get yours from https://newsapi.org/)
API_KEY = "44ff3e954df14081ae19ce50f62a713d"
BASE_URL = "https://newsapi.org/v2/top-headlines?category={}&country=us&apiKey={}"

# Streamlit App
st.title("📰 News Headlines Tracker")

# News Categories
categories = ["Technology", "Business", "Sports", "Health", "Entertainment", "Science"]
category = st.selectbox("Select News Category:", categories)

# Fetch News Function
def get_news(category):
    url = BASE_URL.format(category.lower(), API_KEY)
    response = requests.get(url)

    if response.status_code == 200:
        news_data = response.json()
        return news_data.get("articles", [])
    else:
        st.error("⚠️ Failed to fetch news. Check API key or internet connection.")
        return []

# Fetch and Display News
if st.button("🔄 Get Latest News"):
    news_articles = get_news(category)
    
    if news_articles:
        for article in news_articles[:10]:  # Show only top 10 headlines
            st.subheader(article["title"])
            st.write(article["description"] if article["description"] else "No description available.")
            st.markdown(f"[Read More]({article['url']})")
            st.write("---")
    else:
        st.warning("⚠️ No news found. Try again later.")

